﻿using Harmony;
using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using Verse;

namespace KilledEnemyDontPushOutThings
{
    [StaticConstructorOnStartup]
    public static class Mod
    {
        public const string Name = "KilledEnemyAutoAllowed";
        public static void Debug(object s)
        {
#if DEBUG
            Log.Message($"[{Name}] {s}");
#endif
        }
        public static void Message(string s) => Log.Message($"[{Name}] {s}");
        public static void Warning(string s) => Log.Warning($"[{Name}] {s}");
        public static void Error(string s) => Log.Error($"[{Name}] {s}");
        static Mod()
        {
            Message($"Begin Patch");
            var harmony = HarmonyInstance.Create(Name);
            harmony.PatchAll();
            Message($"Patched");
        }
    }
    public class ModException : Exception
    {
        public ModException(string s) : base($"[{Mod.Name}]{s}") { }
    }
    [HarmonyPatch(typeof(Pawn), "Kill")]
    class Patch1
    {
        static IEnumerable<CodeInstruction> Transpiler(ILGenerator generator, IEnumerable<CodeInstruction> codes) => new TranspilerFactory()
                .Delete("ldloc_s *;call ForbidUtility::SetForbiddenIfOutsideHomeArea(Thing)")
                .WhenFinished(t => Mod.Debug(t))
                .Transpiler(generator, codes);
    }
    [HarmonyPatch(typeof(Pawn), "DropAndForbidEverything")]
    class Patch2
    {
        static IEnumerable<CodeInstruction> Transpiler(ILGenerator generator, IEnumerable<CodeInstruction> codes) => new TranspilerFactory()
                .Replace("ldc.i4.1;callvirt Pawn_EquipmentTracker::DropAllEquipment(IntVec3,Boolean)", "ldc.i4.0;callvirt Pawn_EquipmentTracker::DropAllEquipment(IntVec3,Boolean)")
                .Replace("ldc.i4.1;ldc.i4.0", "ldc.i4.0;ldc.i4.0")
                .WhenFinished(t => Mod.Debug(t))
                .Transpiler(generator, codes);
    }
}